package com.example.narasimha;

public class ModelClass {
    public String phone;

    public ModelClass(String phone){
        this.phone=phone;
    }
}
